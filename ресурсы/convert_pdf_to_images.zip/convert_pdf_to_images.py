import os
import fitz  # PyMuPDF
import tkinter as tk
from tkinter import filedialog, messagebox
from tkinter import ttk  # Для стилизованного OptionMenu
from PIL import Image

def save_image_as_tiff(pix, image_path):
    # Конвертация Pixmap в изображение Pillow
    img = Image.frombytes("RGB", [pix.width, pix.height], pix.samples)
    img.save(image_path, format="TIFF")


def convert_pdf_to_images(pdf_path, output_folder, image_format):
    try:
        pdf_document = fitz.open(pdf_path)
        print(f"Всего страниц: {pdf_document.page_count}")

        for page_num in range(pdf_document.page_count):
            page = pdf_document.load_page(page_num)
            pix = page.get_pixmap()

            # Определяем путь для сохранения
            image_path = os.path.join(
                output_folder,
                f"{os.path.basename(pdf_path)[:-4]}_page_{page_num + 1}.{image_format.lower()}",
            )

            # Если формат TIFF, используем Pillow
            if image_format.lower() == "tiff":
                save_image_as_tiff(pix, image_path)
            else:
                pix.save(image_path)  # Для PNG и JPG

            print(f"Сохранено: {image_path}")
        
        messagebox.showinfo("Успех", f"Изображения сохранены в папке: {output_folder}")
    except Exception as e:
        messagebox.showerror("Ошибка", f"Ошибка при обработке файла {pdf_path}: {e}")

def select_pdf_file():
    pdf_path = filedialog.askopenfilename(
        title="Выберите PDF файл",
        filetypes=[("PDF файлы", "*.pdf")],
    )
    if pdf_path:
        selected_pdf_label.config(text=f"{pdf_path}")  # Полностью заменяем текст
        convert_button.config(state=tk.NORMAL)
        convert_button.pdf_path = pdf_path


def select_output_folder():
    output_folder = filedialog.askdirectory(title="Выберите папку для сохранения")
    if output_folder:
        selected_folder_label.config(text=f"{output_folder}")  # Полностью заменяем текст
        convert_button.output_folder = output_folder

def start_conversion():
    pdf_path = getattr(convert_button, "pdf_path", None)
    output_folder = getattr(convert_button, "output_folder", None)
    image_format = format_var.get()

    if not pdf_path or not output_folder:
        messagebox.showerror("Ошибка", "Пожалуйста, выберите PDF файл и папку для сохранения.")
        return

    convert_pdf_to_images(pdf_path, output_folder, image_format)


# Создание главного окна
root = tk.Tk()
root.title("PDF в Изображения")
root.geometry("500x250")
root.configure(bg="#2e2e2e")

# Тёмная тема
label_fg = "#ffffff"
button_bg = "#444444"
button_fg = "#ffffff"
button_width = 17  # Фиксированная ширина для всех кнопок

# Выбор PDF файла (строка 1)
frame_pdf_button = tk.Frame(root, bg="#2e2e2e")
frame_pdf_button.pack(pady=5, fill="x")

pdf_file_label = tk.Label(frame_pdf_button, text="Выберите PDF файл", fg=label_fg, bg="#2e2e2e", font=("Arial", 12), anchor="w")
pdf_file_label.pack(side="left", padx=10)

select_pdf_button = tk.Button(frame_pdf_button, text="Выбрать PDF", command=select_pdf_file, bg=button_bg, fg=button_fg, width=button_width)
select_pdf_button.pack(side="right", padx=10)

# Отображение выбранного файла на отдельной строке
frame_pdf_path = tk.Frame(root, bg="#2e2e2e")
frame_pdf_path.pack(pady=(0, 10), fill="x")

selected_pdf_label = tk.Label(frame_pdf_path, text="", fg=label_fg, bg="#2e2e2e", font=("Arial", 8), anchor="w", wraplength=480)
selected_pdf_label.pack(fill="x", padx=10)

# Выбор папки для сохранения (строка 2)
frame_folder_button = tk.Frame(root, bg="#2e2e2e")
frame_folder_button.pack(pady=5, fill="x")

output_folder_label = tk.Label(frame_folder_button, text="Выберите папку для сохранения", fg=label_fg, bg="#2e2e2e", font=("Arial", 12), anchor="w")
output_folder_label.pack(side="left", padx=10)

select_folder_button = tk.Button(frame_folder_button, text="Выбрать папку", command=select_output_folder, bg=button_bg, fg=button_fg, width=button_width)
select_folder_button.pack(side="right", padx=10)

# Отображение выбранной папки на отдельной строке
frame_folder_path = tk.Frame(root, bg="#2e2e2e")
frame_folder_path.pack(pady=(0, 10), fill="x")

selected_folder_label = tk.Label(frame_folder_path, text="", fg=label_fg, bg="#2e2e2e", font=("Arial", 8), anchor="w", wraplength=480)
selected_folder_label.pack(fill="x", padx=10)


# Выбор формата изображений (строка 3)
frame_format = tk.Frame(root, bg="#2e2e2e")
frame_format.pack(pady=5, fill="x")

format_label = tk.Label(frame_format, text="Выберите формат изображения:", fg=label_fg, bg="#2e2e2e", font=("Arial", 12), anchor="w")
format_label.pack(side="left", padx=10)

format_var = tk.StringVar(value="JPG")
format_dropdown = ttk.OptionMenu(frame_format, format_var, "JPG", "JPG", "PNG", "TIFF")
format_dropdown.config(width=15)  # Устанавливаем фиксированную ширину
format_dropdown.pack(side="right", padx=14)

# Кнопка конвертации (строка 4)
frame_convert = tk.Frame(root, bg="#2e2e2e")
frame_convert.pack(pady=20, fill="x")

convert_button = tk.Button(
    frame_convert, text="Конвертировать", state=tk.DISABLED, command=start_conversion, bg=button_bg, fg=button_fg, width=button_width
)
convert_button.pack()

root.mainloop()
